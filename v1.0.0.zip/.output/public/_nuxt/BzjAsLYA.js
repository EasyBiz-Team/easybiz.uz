import{_ as e,v as t,t as o}from"./B3NHnTn_.js";const c={};function r(s,n,_,a,p,d){return o(),t("div")}const i=e(c,[["render",r]]);export{i as default};
